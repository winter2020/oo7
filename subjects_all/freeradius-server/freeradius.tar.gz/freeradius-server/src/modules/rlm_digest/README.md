# rlm_digest
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
The digest module performs HTTP digest authentication, usually for a SIP server. See draft-sterman-aaa-sip-00.txt for
details. The module does not support RFC 5090.
