# rlm_linelog
## Metadata
<dl>
  <dt>category</dt><dd>io</dd>
</dl>

## Summary
Creates log entries from attributes, string expansions, or static strings, and writes them to a variety of backends,
including syslog, flat files, and raw UDP/TCP sockets.
