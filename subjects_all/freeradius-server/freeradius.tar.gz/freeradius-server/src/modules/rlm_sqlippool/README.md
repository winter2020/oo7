# rlm_sqlippool
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
SQL based IP allocation module.
