# rlm_redis
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Provides connectivity to single and clustered instances of Redis. This module exposes a string expansion that may be
used to execute queries against Redis.

Other related modules such as rlm_redis_ippool and rlm_rediswho provide additional functionality.
