# rlm_unbound
## Metadata
<dl>
  <dt>category</dt><dd>io</dd>
</dl>

## Summary
Performs queries against a DNS service to allow FQDNs to be resolved during request processing.
