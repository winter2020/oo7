# rlm_sqlhpwiippool
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
High performance SQL based IP allocation module.
