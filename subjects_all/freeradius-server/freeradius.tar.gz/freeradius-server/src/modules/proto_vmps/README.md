# proto_vmps
## Metadata
<dl>
  <dt>category</dt><dd>protocols</dd>
</dl>

## Summary
Implements Cisco's proprietary VQP (VLAN query protocol) allowing FreeRADIUS to act as a VMPS (VLAN Management Policy
Server).
