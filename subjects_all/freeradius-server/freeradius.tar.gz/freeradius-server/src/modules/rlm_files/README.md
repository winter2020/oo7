# rlm_files
## Metadata
<dl>
  <dt>category</dt><dd>io</dd>
</dl>

## Summary
Implements a traditional Livingston-style users file.

Entries in the users file can check for certain attributes and values in the current request, and add new attributes
if they're found.
