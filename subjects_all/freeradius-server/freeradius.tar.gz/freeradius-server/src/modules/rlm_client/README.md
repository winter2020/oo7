# rlm_dynamic_clients
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Reads client definitions from flat files.
