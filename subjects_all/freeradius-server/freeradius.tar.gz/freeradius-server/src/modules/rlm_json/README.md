# rlm_json
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary
Parses JSON strings into an in memory format using the json-c library.

Implements a very simple xpathlike query syntax, allowing values to be extracted and added to the request as attributes.
