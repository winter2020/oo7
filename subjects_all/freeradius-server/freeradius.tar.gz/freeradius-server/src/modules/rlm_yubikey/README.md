# rlm_yubikey
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
Supports authentication of yubikey tokens where the PSK is known to FreeRADIUS, and integrates with the Yubico
cloud-based authentication service.
