# rlm_utf8
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary
Checks all attributes of type string in the current request, to ensure that they only contain valid UTF8 sequences.
