# rlm_soh
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
Implements support for Microsoft's Statement of Health (SoH) protocol, which can run inside of PEAP or DHCP.
