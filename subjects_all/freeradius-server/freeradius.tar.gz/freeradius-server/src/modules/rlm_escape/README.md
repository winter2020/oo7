# rlm_escape
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary
Escapes and unescapes strings using the MIME escape format
