# rlm_eap_aka
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
Implements [RFC 4186](https://tools.ietf.org/html/rfc4186) EAP-SIM authentication.  EAP-SIM provides authentication
and session keying material for 802.11i (WPA/2 Enterprise) using SIM triplets.
