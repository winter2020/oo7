# proto_arp
## Metadata
<dl>
  <dt>category</dt><dd>protocols</dd>
</dl>

## Summary
Decodes ARP packets, converting them to FreeRADIUS internal attributes. Allows passive network discovery and network inventory.
