# rlm_pap
## Metadata
<dl>
  <dt>category</dt><dd>authentication</dd>
</dl>

## Summary
Accepts a large number of formats for the "known good" (reference) password, such as crypt hashes, md5 hashes,
and etc. The module takes the User-Password and performs the necessary transformations of the user submitted password
to match the copy of the password the server has retrieved.
