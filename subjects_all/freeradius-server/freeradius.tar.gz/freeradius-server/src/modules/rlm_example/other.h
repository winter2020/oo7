#pragma once
/* @copyright 2006 The FreeRADIUS server project */
RCSIDH(other_h, "$Id: 5f4a3ac4b183f88f098e148c32339a4dbbe158f1 $")

/* define the function */

void other_function(void);
