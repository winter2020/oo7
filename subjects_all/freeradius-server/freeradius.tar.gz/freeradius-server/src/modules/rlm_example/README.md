# rlm_example
## Metadata
<dl>
  <dt>category</dt><dd>policy</dd>
</dl>

## Summary
An example module to use as a template when writing new modules.
