# rlm_cache_rbtree
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Stores cache entries in an internal rbtree. It is a submodule of rlm_cache and cannot be used on its own.
