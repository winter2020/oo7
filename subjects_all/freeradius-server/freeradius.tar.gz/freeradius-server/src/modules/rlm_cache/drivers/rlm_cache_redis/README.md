# rlm_cache_redis
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Stores cache entries to be written to and retrieved from a Redis server, or cluster of Redis servers. It is a submodule
of rlm_cache and cannot be used on its own.
