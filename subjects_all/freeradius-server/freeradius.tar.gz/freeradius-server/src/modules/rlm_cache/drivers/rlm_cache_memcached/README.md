# rlm_cache_memcached
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Allows cache entries to written to and retrieved from a memcached server. It is a submodule of rlm_cache and cannot be
used on its own.
