# rlm_cache
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Stores attributes and/or lists and adds them back to a subsequent request or to the current request on a later execution
of the module.
