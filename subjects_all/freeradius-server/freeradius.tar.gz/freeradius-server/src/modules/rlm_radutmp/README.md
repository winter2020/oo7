# rlm_radutmp
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Writes a utmp style file that lists the users who are logged in. The file is used mainly for Simultaneous-Use checking
and by radwho to see who has current sessions.
