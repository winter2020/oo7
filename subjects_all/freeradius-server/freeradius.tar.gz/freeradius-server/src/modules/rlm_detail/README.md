# rlm_detail
## Metadata
<dl>
  <dt>category</dt><dd>io</dd>
</dl>

## Summary
Writes attributes from a request list to a flat file in 'detail' format.
