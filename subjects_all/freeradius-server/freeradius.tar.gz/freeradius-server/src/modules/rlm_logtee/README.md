# rlm_logtee
## Metadata
<dl>
  <dt>category</dt><dd>io</dd>
</dl>

## Summary
Tee's request logging at runtime, sending it to additional log destinations.
