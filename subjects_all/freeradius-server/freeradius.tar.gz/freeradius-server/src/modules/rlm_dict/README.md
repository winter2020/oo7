# rlm_dict
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Registers xlats and maps to access dictionary data
