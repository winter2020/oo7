# proto_ldap_sync
## Metadata
<dl>
  <dt>category</dt><dd>datastore</dd>
</dl>

## Summary
Gives the ability to perform persistent searches against LDAP
directories.

