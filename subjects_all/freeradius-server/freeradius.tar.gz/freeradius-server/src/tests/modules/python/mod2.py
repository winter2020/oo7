import radiusd

def authorize(p):   
    return radiusd.RLM_MODULE_OK