#!/bin/sh
exec ./test-u32-nfc-big${EXEEXT} "$srcdir/uninorm/NormalizationTest.txt"
