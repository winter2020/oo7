#!/bin/sh
exec ./test-u32-nfkd-big${EXEEXT} "$srcdir/uninorm/NormalizationTest.txt"
