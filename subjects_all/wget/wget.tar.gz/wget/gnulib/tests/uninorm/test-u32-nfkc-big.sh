#!/bin/sh
exec ./test-u32-nfkc-big${EXEEXT} "$srcdir/uninorm/NormalizationTest.txt"
