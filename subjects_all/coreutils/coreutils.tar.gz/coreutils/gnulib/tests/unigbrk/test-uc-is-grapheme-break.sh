#!/bin/sh

./test-uc-is-grapheme-break${EXEEXT} "${srcdir}/unigbrk/GraphemeBreakTest.txt"
