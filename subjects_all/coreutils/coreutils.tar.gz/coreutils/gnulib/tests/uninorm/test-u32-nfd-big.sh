#!/bin/sh
exec ./test-u32-nfd-big${EXEEXT} "$srcdir/uninorm/NormalizationTest.txt"
