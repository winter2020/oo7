**netdata**<br/>
(C) Copyright 2017<br/>
Costa Tsaousis &lt;costa@tsaousis.gr&gt;

For license details refer to the following files:

- [netdata license](LICENSE) (GPL v3+)
- [third party licenses](LICENSE-REDISTRIBUTED.md), for packages re-distributed with netdata

