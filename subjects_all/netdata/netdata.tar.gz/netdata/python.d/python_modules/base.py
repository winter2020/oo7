# -*- coding: utf-8 -*-
# Description: backward compatibility with old version

from bases.FrameworkServices.SimpleService import SimpleService
from bases.FrameworkServices.UrlService import UrlService
from bases.FrameworkServices.SocketService import SocketService
from bases.FrameworkServices.LogService import LogService
from bases.FrameworkServices.ExecutableService import ExecutableService
from bases.FrameworkServices.MySQLService import MySQLService
