#ifndef NETDATA_PLUGIN_TC_H
#define NETDATA_PLUGIN_TC_H 1

extern void *tc_main(void *ptr);

#endif /* NETDATA_PLUGIN_TC_H */

