#!/bin/bash

bap ../dropbear --recipe=ddtbd
